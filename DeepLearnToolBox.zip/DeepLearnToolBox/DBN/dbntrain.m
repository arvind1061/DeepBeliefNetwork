function [dbn,rerror] = dbntrain(dbn, x, opts) % function definition
    n = numel(dbn.rbm); % returns the no of elements in array dbn.rbm
    dbn.rbm{1} = rbmtrain(dbn.rbm{1}, x, opts); % training for the first set of column vectors 
    for i = 2 : n
        x = rbmup(dbn.rbm{i - 1}, x); % creates the copy of dbn.rbm
        [dbn.rbm{i},re] = rbmtrain(dbn.rbm{i}, x, opts); %training the NW with rest of the vectors and returning the error
        if i == n 
            rerror = re; % for storing the last error
        end
    end
end
