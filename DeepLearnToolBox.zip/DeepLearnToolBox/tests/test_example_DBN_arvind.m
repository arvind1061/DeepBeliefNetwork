function er = test_example_DBN_arvind  %function definition
load frey_rawface;                      %loading the data set

ff = ff(:,1:1800);                      % deciding the data size to consider as trainin data and test data
n = size(ff,2);                         % size of the dataset
train_x = transpose(ff(:,1:floor(n/2)));% half of the data set is training dataset and half of the dataset is test data 
test_x = transpose(ff(:,ceil(n/2):n));

train_x = double(train_x) / 255;  %normalizing trainig data and test data
test_x  = double(test_x)  / 255;
%train_y = double(train_y);
%test_y  = double(test_y);

er = [];
%%  ex1 train a 100 hidden unit RBM and visualize its weights
for i=1:10:560
    rand('state',0)            
    % two hidden layer DBN each with variable no. of nodes   
    dbn.sizes = [i+50 i];    
    opts.numepochs =   1;  %no. of times the network should be trained
    opts.batchsize = 50;   % no. of samples of data sets to train the NW
    % momentum describes the fraction of previous wt added to update the
    % current wt. typically between [0,1]; high value causes system to
    % become unstable
    opts.momentum  =   0;   
    opts.alpha     =   1;  %learning rate varies between [0,1]
    dbn = dbnsetup(dbn, train_x, opts);   %function call to setup the NW
    [dbn,ey] = dbntrain(dbn, train_x, opts);   % function to train the NW with the given data set
    er = [er ey];          % creating a vector of errors for plotting
      
    %figure; visualize(dbn.rbm{1}.W');   %  Visualize the RBM weights    
end

x = 1:10:560;
plot(x,er);  %plotting the errors
[val,ind] = min(er);
x(ind)