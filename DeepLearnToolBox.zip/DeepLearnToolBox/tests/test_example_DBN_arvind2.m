function dbn = test_example_DBN_arvind2
load olivettifaces;

faces = faces(:,1:400);
n = size(faces,2);
train_x = transpose(faces(:,1:floor(n/2)));
test_x = transpose(faces(:,ceil(n/2):n));

train_x = double(train_x) / 255;
test_x  = double(test_x)  / 255;
%train_y = double(train_y);
%test_y  = double(test_y);

er = [];
%%  ex1 train a 100 hidden unit RBM and visualize its weights
for i=1:100:4000
    rand('state',0)
    dbn.sizes = [i+100 i];    
    opts.numepochs =   1;
    opts.batchsize = 50;
    opts.momentum  =   0;
    opts.alpha     =   1;
    dbn = dbnsetup(dbn, train_x, opts);
    [dbn,ey] = dbntrain(dbn, train_x, opts);
    er = [er ey];
    mm = [min(dbn.rbm{1}.W(:)) max(dbn.rbm{1}.W(:))];
    %figure; visualize(dbn.rbm{1}.W');   %  Visualize the RBM weights    
end

x = 1:100:4000
plot(x,er,'-.');
